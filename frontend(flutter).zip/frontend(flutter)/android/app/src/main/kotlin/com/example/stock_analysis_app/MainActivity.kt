package com.example.stock_analysis_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
